THIS IS WORK IN PROGRESS.

These are shapefiles for the Holy Roman Empire from the 10th century to 1137, mostly based on the map "Germany from the beginning of the X century to 1137"('Deutschland vom Anfange des X. Jahrhunderts bis 1137') by Theodor Menke in "Hand-Atlas für die Geschichte des Mittelalters und der neueren Zeit" by Karl von Spruner, newly revised by Theodor Menke (Gotha 1880, nr. 37). A .jped file of the map is attached under "Template", the entire atlas is available at: https://gei-digital.gei.de/viewer/!toc/PPN685000710/84/-/

The map was imported into QGis by georeferencing and the boundaries were transferred. Additional templates were used for details.

The template was in the public domain, I hereby make these shapefiles available under the Attribution-ShareAlike (CC BY-SA) license. This means that reuse and modification is allowed under two conditions: 1. credit to the author (me) and 2. also the result must be made available under this license.

I hope these files help you!

If you do something cool with it, I would be happy about a hint. 

If you want to stay up to date about my work, feel free to follow me on TwiX: https://twitter.com/3mKa1 / Mastodon: @manuel_kamenzin@troet.cafe / Blue Sky: @manuel-kamenzin.bsky.social.

Last but not least: Be kind, have fun!

Best
Manuel Kamenzin (november 2023)

